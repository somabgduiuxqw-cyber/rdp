# ATP Temp Mail Bot v1

## Included
- Mail.tm mailbox creation and inbox reading
- 1 credit for a normal mailbox (password hidden)
- 3 credits for a mailbox whose password is shown
- Referral deep links: one credit per newly registered referred user
- Owner-only redeem-code creation
- Redeem-code limits: 1 / 10 / 50 / 100 users
- Credits per redemption: 10 / 50 / 100 / 1000
- A user can redeem each code only once
- SQLite persistence

## Configuration

Set environment variables before running:

```bash
export BOT_TOKEN="YOUR_TELEGRAM_BOT_TOKEN"
export OWNER_ID="9232177140"
python main.py
```

Install:

```bash
python -m pip install -r requirements.txt
```

## Required Telegram setup
1. Add the bot as an administrator in both `@dragomethods` and `@atp_nst`.
2. The bot needs permission to view members / get chat member status.
3. Keep both channels public, or adapt the channel identifiers and invite links if private.
4. Users are asked to join both channels. Membership is checked on bot interactions.
5. If a user is no longer a member of `@atp_nst`, their remaining credits are cleared on the next interaction.

## Database
The bot creates `atp_temp_mail.db` automatically. It contains users, referrals, redeem codes, redemptions, and mailbox credentials/tokens.

**Security:** Do not share the database or bot token. Mailbox passwords and Mail.tm access tokens are stored locally so the bot can read inboxes. Normal-mailbox passwords are hidden from the user, not deleted. Use this only for legitimate testing and services that permit temporary email addresses.

## Important v1 limitations
- Membership is rechecked when a user interacts; Telegram polling does not guarantee instant leave detection.
- This starter version keeps the latest mailbox as the active inbox.
- Mail.tm availability, account creation limits, and mailbox retention are controlled by Mail.tm.
- The bot does not send emails.
